# 吉林外卖（jilin-takeout）项目记忆

## 项目基本信息
- **本地路径**：`c:\Users\Administrator\Desktop\xinxiangmh\oneday_zip_1776721924659`
- **GitHub 仓库**：`9195721/jilin-takeout`（注意：国内网络经常连不上 GitHub）
- **技术栈**：React 18 + TS + Vite + Tailwind，webpack 构建
- **构建产物**：`dist/` 目录（index.html + bundle.*.js）

## Vercel 部署信息（核心！）

### 正确的项目
- **Vercel 项目名**：`jilin-takeout-5s4v`（⚠️ 不是 `jilin-takeout`，域名绑在这个上）
- **Vercel Project ID**：`prj_UN1ERlR9hhymAWxLAdIHk82KsRvZ`

### 域名绑定
- **主域名**：`https://moojilin55.site`
- **www 域名**：`https://www.moojilin55.site`
- **自动跳转**：moojilin55.site → www.moojilin55.site

### 部署方式（绕过 GitHub）
```bash
# 1. 链接到正确项目
vercel link --project jilin-takeout-5s4v --token vcp_3sBtAXHNlyY5pXK9ldAwQOXi4yMuOxf3vMFoos6fa24gTwayVl16jnxl --yes

# 2. 直接部署到生产环境
vercel --token vcp_3sBtAXHNlyY5pXK9ldAwQOXi4yMuOxf3vMFoos6fa24gTwayVl16jnxl --prod --yes
```

### vercel.json 关键配置
- `buildCommand: ""` — 跳过构建（dist/ 已有产物）
- `installCommand: ""` — 跳过 pnpm install（阿里云镜像会超时）
- `outputDirectory: "dist"` — 静态托管 dist/
- `rewrites: [{source: "/(.*)", destination: "/index.html"}]` — SPA 路由回退

## Supabase 数据库
- **URL**：`https://edclbolgjqozkjmnlwmp.supabase.co`
- **建表 SQL**：`migrations/` 目录下共 9 个 .sql 文件

## COS 对象存储
- **Bucket**：`lee2111-1419902782`
- **Region**：`ap-beijing`

## 常见问题速查
| 问题 | 解决 |
|------|------|
| 网站 404 | 用 Vercel CLI + Token 重部署到 `jilin-takeout-5s4v` |
| pnpm install 超时 | vercel.json 加 `installCommand: ""` 跳过 |
| GitHub push 失败 | 不用 git push，直接用 Vercel CLI 部署 |
| 域名不生效 | 确认部署到了 `jilin-takeout-5s4v` 项目 |

## 更新记录
- 2026-04-21：首次整理完整部署信息，网站成功上线
